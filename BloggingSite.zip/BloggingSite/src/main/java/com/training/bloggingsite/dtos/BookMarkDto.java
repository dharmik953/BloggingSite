package com.training.bloggingsite.dtos;

import com.training.bloggingsite.entities.Post;
import com.training.bloggingsite.entities.User;

import java.util.HashSet;
import java.util.Set;

public class BookMarkDto {
    long id;
    Post post;
    User user;

}
